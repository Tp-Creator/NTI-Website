<html>
<head>
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="-1">
<meta http-equiv="refresh" content="30">
<!--link rel="stylesheet" href="style.css"-->
<link href='https://fonts.googleapis.com/css?family=Orbitron' rel='stylesheet' type='text/css'>
<style>
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@700&display=swap');
h2{color: #ce0f47;padding-top:0px;padding-left:12px;font-family: 'Poppins', 'Orbitron', sans-serif;}
</style>
</head>
<body>
<h2>
<?php
echo date('H').":".date("i");
?>
</h2>
</body>
</html>
