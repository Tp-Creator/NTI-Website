<html>
<head>
<title>TV Admin</title>
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="-1">
<meta http-equiv="refresh" content="0;URL='list.php'" />
</head>
<body>
</body>
</html>
