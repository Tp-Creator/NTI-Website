<html>
<head>
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="-1">
<meta http-equiv="refresh" content="30">
<link href='https://fonts.googleapis.com/css?family=Orbitron' rel='stylesheet' type='text/css'>
<style>
h2{color: #663399;padding-top:0px;padding-left:12px;font-family: 'Orbitron', sans-serif;}
</style>
</head>
<body>
<h2>
<?php
echo date('H').":".date("i");
?>
</h2>
</body>
</html>
